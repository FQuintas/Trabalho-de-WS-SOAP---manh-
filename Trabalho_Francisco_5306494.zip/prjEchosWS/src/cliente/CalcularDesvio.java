
package cliente;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de calcularDesvio complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conte�do esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="calcularDesvio">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="qtdDesvios" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "calcularDesvio", propOrder = {
    "qtdDesvios"
})
public class CalcularDesvio {

    protected int qtdDesvios;

    /**
     * Obt�m o valor da propriedade qtdDesvios.
     * 
     */
    public int getQtdDesvios() {
        return qtdDesvios;
    }

    /**
     * Define o valor da propriedade qtdDesvios.
     * 
     */
    public void setQtdDesvios(int value) {
        this.qtdDesvios = value;
    }

}
