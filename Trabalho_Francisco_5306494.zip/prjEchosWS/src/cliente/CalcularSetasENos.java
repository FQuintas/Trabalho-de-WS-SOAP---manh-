
package cliente;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de calcularSetasENos complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conte�do esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="calcularSetasENos">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="qtdSetas" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="qtdNos" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "calcularSetasENos", propOrder = {
    "qtdSetas",
    "qtdNos"
})
public class CalcularSetasENos {

    protected int qtdSetas;
    protected int qtdNos;

    /**
     * Obt�m o valor da propriedade qtdSetas.
     * 
     */
    public int getQtdSetas() {
        return qtdSetas;
    }

    /**
     * Define o valor da propriedade qtdSetas.
     * 
     */
    public void setQtdSetas(int value) {
        this.qtdSetas = value;
    }

    /**
     * Obt�m o valor da propriedade qtdNos.
     * 
     */
    public int getQtdNos() {
        return qtdNos;
    }

    /**
     * Define o valor da propriedade qtdNos.
     * 
     */
    public void setQtdNos(int value) {
        this.qtdNos = value;
    }

}
