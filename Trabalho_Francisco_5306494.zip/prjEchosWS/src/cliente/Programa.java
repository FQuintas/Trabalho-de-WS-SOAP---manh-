package cliente;

import java.util.Scanner;
import control.Echo.*;

public class Programa {

	public static void main(String[] args) {
		Echo echo = new EchoService().getEchoPort();

		System.out.println("Calculadora ciclomatica");
		System.out.println("Digite 1 para calcular por meio dos bols�es existentes no grafo, bolsoes s�o espa�os fechados no grafo.");
		System.out.println("Digite 2 para calcular por meio de quantas setas o grafo possui e quantos n�s.");
		System.out.println("Digite 3 para calcular por meio da quantidade de desvios tem no grafo, ex else.");

		Scanner scan = new Scanner(System.in);
		int opcao = scan.nextInt();

		switch (opcao) {
		case 1:
			System.out.println("bols�es existem no grafo, bolsoes s�o espa�os fechados no grafo.");
			Scanner op1 = new Scanner(System.in);
			int qtdBolsoes = op1.nextInt();
			System.out.print("complexidade ciclomatica = " + echo.calcularBolsoes(qtdBolsoes));
			break;

		case 2:
			System.out.println("quantas setas o grafo possui.");
			Scanner op2 = new Scanner(System.in);
			int qtdSetas = op2.nextInt();

			System.out.println("quantos n�s o grafo possui.");
			int qtdNos = op2.nextInt();

			System.out.print("complexidade ciclomatica = " + echo.calcularSetasENos(qtdSetas, qtdNos));
			break;

		case 3:
			System.out.println("quantos desvios tem no grafo, ex else.");
			Scanner op3 = new Scanner(System.in);
			int qtdDesvios = op3.nextInt();
			System.out.print("complexidade ciclomatica = " + echo.calcularDesvio(qtdDesvios));
			break;

		default:
			System.out.println("Apenas valores 1, 2 e 3 ser�o aceitos.");
		}

	}

}
