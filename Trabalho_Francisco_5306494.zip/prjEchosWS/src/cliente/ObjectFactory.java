
package cliente;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the cliente package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _CalcularDesvioResponse_QNAME = new QName("http://control/", "calcularDesvioResponse");
    private final static QName _CalcularBolsoesResponse_QNAME = new QName("http://control/", "calcularBolsoesResponse");
    private final static QName _CalcularSetasENos_QNAME = new QName("http://control/", "calcularSetasENos");
    private final static QName _CalcularBolsoes_QNAME = new QName("http://control/", "calcularBolsoes");
    private final static QName _CalcularDesvio_QNAME = new QName("http://control/", "calcularDesvio");
    private final static QName _CalcularSetasENosResponse_QNAME = new QName("http://control/", "calcularSetasENosResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: cliente
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link CalcularSetasENosResponse }
     * 
     */
    public CalcularSetasENosResponse createCalcularSetasENosResponse() {
        return new CalcularSetasENosResponse();
    }

    /**
     * Create an instance of {@link CalcularBolsoes }
     * 
     */
    public CalcularBolsoes createCalcularBolsoes() {
        return new CalcularBolsoes();
    }

    /**
     * Create an instance of {@link CalcularDesvio }
     * 
     */
    public CalcularDesvio createCalcularDesvio() {
        return new CalcularDesvio();
    }

    /**
     * Create an instance of {@link CalcularSetasENos }
     * 
     */
    public CalcularSetasENos createCalcularSetasENos() {
        return new CalcularSetasENos();
    }

    /**
     * Create an instance of {@link CalcularBolsoesResponse }
     * 
     */
    public CalcularBolsoesResponse createCalcularBolsoesResponse() {
        return new CalcularBolsoesResponse();
    }

    /**
     * Create an instance of {@link CalcularDesvioResponse }
     * 
     */
    public CalcularDesvioResponse createCalcularDesvioResponse() {
        return new CalcularDesvioResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalcularDesvioResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://control/", name = "calcularDesvioResponse")
    public JAXBElement<CalcularDesvioResponse> createCalcularDesvioResponse(CalcularDesvioResponse value) {
        return new JAXBElement<CalcularDesvioResponse>(_CalcularDesvioResponse_QNAME, CalcularDesvioResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalcularBolsoesResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://control/", name = "calcularBolsoesResponse")
    public JAXBElement<CalcularBolsoesResponse> createCalcularBolsoesResponse(CalcularBolsoesResponse value) {
        return new JAXBElement<CalcularBolsoesResponse>(_CalcularBolsoesResponse_QNAME, CalcularBolsoesResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalcularSetasENos }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://control/", name = "calcularSetasENos")
    public JAXBElement<CalcularSetasENos> createCalcularSetasENos(CalcularSetasENos value) {
        return new JAXBElement<CalcularSetasENos>(_CalcularSetasENos_QNAME, CalcularSetasENos.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalcularBolsoes }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://control/", name = "calcularBolsoes")
    public JAXBElement<CalcularBolsoes> createCalcularBolsoes(CalcularBolsoes value) {
        return new JAXBElement<CalcularBolsoes>(_CalcularBolsoes_QNAME, CalcularBolsoes.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalcularDesvio }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://control/", name = "calcularDesvio")
    public JAXBElement<CalcularDesvio> createCalcularDesvio(CalcularDesvio value) {
        return new JAXBElement<CalcularDesvio>(_CalcularDesvio_QNAME, CalcularDesvio.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalcularSetasENosResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://control/", name = "calcularSetasENosResponse")
    public JAXBElement<CalcularSetasENosResponse> createCalcularSetasENosResponse(CalcularSetasENosResponse value) {
        return new JAXBElement<CalcularSetasENosResponse>(_CalcularSetasENosResponse_QNAME, CalcularSetasENosResponse.class, null, value);
    }

}
