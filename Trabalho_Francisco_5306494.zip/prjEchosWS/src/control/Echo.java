package control;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

@WebService
public class Echo {
	@WebMethod
	public int calcularBolsoes(@WebParam(name = "qtdBolsoes") int qtdBolsoes) {
		int result = qtdBolsoes + 1;

		return result;
	}

	@WebMethod
	public int calcularSetasENos(@WebParam(name = "qtdSetas") int qtdSetas, @WebParam(name = "qtdNos") int qtdNos) {
		int result = qtdSetas - qtdNos + 2;

		return result;
	}

	@WebMethod
	public int calcularDesvio(@WebParam(name = "qtdDesvios") int qtdDesvio) {
		int result = qtdDesvio + 1;

		return result;
	}

}