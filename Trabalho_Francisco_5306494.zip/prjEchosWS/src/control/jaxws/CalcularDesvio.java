
package control.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "calcularDesvio", namespace = "http://control/")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "calcularDesvio", namespace = "http://control/")
public class CalcularDesvio {

    @XmlElement(name = "qtdDesvios", namespace = "")
    private int qtdDesvios;

    /**
     * 
     * @return
     *     returns int
     */
    public int getQtdDesvios() {
        return this.qtdDesvios;
    }

    /**
     * 
     * @param qtdDesvios
     *     the value for the qtdDesvios property
     */
    public void setQtdDesvios(int qtdDesvios) {
        this.qtdDesvios = qtdDesvios;
    }

}
