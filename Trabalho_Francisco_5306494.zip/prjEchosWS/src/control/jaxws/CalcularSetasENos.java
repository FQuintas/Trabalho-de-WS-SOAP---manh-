
package control.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "calcularSetasENos", namespace = "http://control/")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "calcularSetasENos", namespace = "http://control/", propOrder = {
    "qtdSetas",
    "qtdNos"
})
public class CalcularSetasENos {

    @XmlElement(name = "qtdSetas", namespace = "")
    private int qtdSetas;
    @XmlElement(name = "qtdNos", namespace = "")
    private int qtdNos;

    /**
     * 
     * @return
     *     returns int
     */
    public int getQtdSetas() {
        return this.qtdSetas;
    }

    /**
     * 
     * @param qtdSetas
     *     the value for the qtdSetas property
     */
    public void setQtdSetas(int qtdSetas) {
        this.qtdSetas = qtdSetas;
    }

    /**
     * 
     * @return
     *     returns int
     */
    public int getQtdNos() {
        return this.qtdNos;
    }

    /**
     * 
     * @param qtdNos
     *     the value for the qtdNos property
     */
    public void setQtdNos(int qtdNos) {
        this.qtdNos = qtdNos;
    }

}
