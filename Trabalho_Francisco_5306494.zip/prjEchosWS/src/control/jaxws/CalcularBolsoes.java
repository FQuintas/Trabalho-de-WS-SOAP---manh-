
package control.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "calcularBolsoes", namespace = "http://control/")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "calcularBolsoes", namespace = "http://control/")
public class CalcularBolsoes {

    @XmlElement(name = "qtdBolsoes", namespace = "")
    private int qtdBolsoes;

    /**
     * 
     * @return
     *     returns int
     */
    public int getQtdBolsoes() {
        return this.qtdBolsoes;
    }

    /**
     * 
     * @param qtdBolsoes
     *     the value for the qtdBolsoes property
     */
    public void setQtdBolsoes(int qtdBolsoes) {
        this.qtdBolsoes = qtdBolsoes;
    }

}
